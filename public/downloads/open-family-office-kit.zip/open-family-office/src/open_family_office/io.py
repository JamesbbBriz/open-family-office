from __future__ import annotations
import json
import os
from pathlib import Path
from typing import Any
from .core import InputError
from .resources import PACKAGE_ROOT, source_checkout

SOURCE_ROOT = source_checkout()
REPO_ROOT = SOURCE_ROOT or PACKAGE_ROOT
MAX_INPUT_BYTES = 10_000_000

def unique_object(pairs: list[tuple[str, Any]]) -> dict:
    result: dict = {}
    for key, value in pairs:
        if key in result:
            raise InputError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result

def read_json(path: str | Path) -> dict:
    path = Path(path).expanduser()
    if not path.is_file():
        raise InputError(f"JSON file not found: {path}")
    if path.stat().st_size > MAX_INPUT_BYTES:
        raise InputError("Input exceeds 10 MB limit")
    with path.open(encoding="utf-8-sig") as stream:
        data = json.load(
            stream,
            object_pairs_hook=unique_object,
            parse_constant=lambda text: (_ for _ in ()).throw(InputError(f"Invalid JSON constant: {text}")),
        )
    if not isinstance(data, dict):
        raise InputError("Top-level JSON must be an object")
    return data

def _inside(target: Path, root: Path) -> bool:
    return target == root or root in target.parents

def outside_repo(path: str | Path) -> Path:
    target = Path(path).expanduser().resolve()
    protected = [PACKAGE_ROOT.resolve()]
    if SOURCE_ROOT is not None:
        protected.append(SOURCE_ROOT.resolve())
    if any(_inside(target, root) for root in protected):
        raise InputError("Private output must be outside the Open Family Office code installation")
    return target

def write_new(path: str | Path, content: str) -> Path:
    target = outside_repo(path)
    target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    descriptor = os.open(target, flags, 0o600)
    with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
        stream.write(content)
    return target
